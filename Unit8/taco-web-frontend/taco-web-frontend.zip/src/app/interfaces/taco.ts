export interface Taco {
  id: number;
  name: string;
  cost: number;
  softShell: boolean;
  chips: boolean;
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-combo-list',
  standalone: true,
  imports: [],
  templateUrl: './combo-list.component.html',
  styleUrl: './combo-list.component.css'
})
export class ComboListComponent {

}

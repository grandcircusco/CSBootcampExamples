import { Component } from '@angular/core';

@Component({
  selector: 'app-drink-list',
  standalone: true,
  imports: [],
  templateUrl: './drink-list.component.html',
  styleUrl: './drink-list.component.css'
})
export class DrinkListComponent {

}

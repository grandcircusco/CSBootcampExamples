# Taco Web Angular Front End

This project provides a front end for the Taco API lab.

## Setup

Run `npm install` to download dependencies before starting the app.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.